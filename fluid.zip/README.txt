# Proyecto_Fluidos_Arquitectura
En fluid se encuentra el programa principal. En sim se encuentran los diferentes componentes.
En utest se encuentran las pruebas unitarias de todos los componentes.
En la raiz se encuentran tests funcionales en shell scripts que complementan a los tests unitarios de progargs_test,
y que esperan ser ejecutados desde la raíz, pasando como parámetro el nombre del directorio de la build (i.e. bldrel).
En files se encuentran archivos binarios de entrada utilizados para la ejecución del programa y para algunos tests,
así como archivos de salida generados por el programa.